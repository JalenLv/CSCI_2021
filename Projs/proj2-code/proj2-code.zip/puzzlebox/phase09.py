letters = "fwboWHMvelATUFpgOyzqdCRZcSjaPstEBhLDKXIYViNrQmxGukJn"
chong_l = "Waldo"

index_W = letters.index("W")
index_a = letters.index("a")
index_l = letters.index("l")
index_d = letters.index("d")
index_o = letters.index("o")

print(index_W, index_a, index_l, index_d, index_o)

